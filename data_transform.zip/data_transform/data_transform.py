# 以 utf-8 的编码格式打开指定文件
import os
import numpy as np

def read_data(path):
    ue_coor_dic = {}
    ap_coor_dic = {}
    index_ue_ap4_dic ={}

    ue = np.loadtxt(path + "/agent.txt", delimiter=',')
    ue_index = np.loadtxt(path + "/agent_index.txt", delimiter=',')
    ap = np.loadtxt(path + "/anchor.txt", delimiter=',')
    ap_index = np.loadtxt(path + "/anchor_index.txt", delimiter=',')
    index_an_ap4 = np.loadtxt(path + "/index_an_ag4.txt", delimiter=',')
    for i1 in range(len(ue)):
        ue_coor_dic[ue_index[i1]] = ue[i1]
        index_ue_ap4_dic[ue_index[i1]] = index_an_ap4[i1]
    for i1 in range (len (ap)):
        ap_coor_dic[ap_index[i1]] = ap[i1]

    return ue_coor_dic, ap_coor_dic,index_ue_ap4_dic
def get_ue_information():
    path = "data_huawei/data"
    files = os.listdir (path)
    UE_DIC = {}
    for file in files:
        position = path + '/' + file
        with open (position, 'r', encoding="utf-8") as f:
            matrix1 = []
            for line1 in f.readlines ():
                line1 = line1.strip ()  # 去除'\n'换行符
                matrix1.append (line1)

            # print(file)
            BS_POS0 = matrix1.index ("BS Pos")
            UE_POS0 = matrix1.index ("UE Pos")
            bs_idx = matrix1.index ("BS TRP ID")
            TOA_STD = matrix1.index ("TOA_STD")
            std_list = []
            std_index = []
            for v in range (0, len (matrix1)):
                if "TOA_STD" == matrix1[v]:
                    pos = int (v)
                    std_index.append (pos + 1)
                    std_list.append (matrix1[pos + 1])

            min_index = int (std_list.index (min (std_list)))
            mat_index = std_index[min_index]
            min_std = [matrix1[mat_index], matrix1[mat_index + 1], matrix1[mat_index + 2], matrix1[mat_index + 3]]
            toa = [matrix1[mat_index - 5], matrix1[mat_index - 4], matrix1[mat_index - 3], matrix1[mat_index - 2]]
            rsrp = [matrix1[mat_index + 15], matrix1[mat_index + 16], matrix1[mat_index + 17], matrix1[mat_index + 18]]

            UE_DIC[file[:-4]] = {'TOA_STD': min_std, 'TOA': toa, 'RSRP': rsrp}
            # print(UE_DIC)
            #UE_DIC_LIST.append (UE_DIC)
    return UE_DIC


def cal_measured_tdoa(toa_list):
    d_tdoa = []
    for i in range (len (toa_list)):
        for j in range (i + 1, len (toa_list)):
            d_tdoa.append ((float(toa_list[i]) - float(toa_list[j]))*0.3)
    return d_tdoa
def cal_real_tdoa(ue,ap4):
    d_tdoa = []
    for i1 in range(len(ap4)-1):
        for i2 in range(i1 + 1, len(ap4)):
            d_tdoa.append(np.linalg.norm(ue-ap4[i1]) - np.linalg.norm(ue-ap4[i2]))
    return d_tdoa

class Scene:
    def __init__(self, data_path):
        self.ue_coor_dic, self.ap_coor_dic, self.index_ue_ap4_dic = read_data (data_path)
        self.ap_know_index = []
        self.dis_measure = self.cal_measured_dis()
        self.dis_real = self.cal_real_dis()


    def cal_measured_dis(self):
        ue_4dis = {}
        ue_4information = get_ue_information()
        for key in ue_4information.keys():
            toa_list = ue_4information[key]['TOA']
            ue_4dis[key] = cal_measured_tdoa(toa_list)
        return ue_4dis

    def cal_real_dis(self):
        ue_4dis = {}
        for key in self.index_ue_ap4_dic.keys():
            ap4 = []
            for i2 in self.index_ue_ap4_dic[key]:
                ap4.append(self.ap_coor_dic[i2])
            ue_4dis[key] = cal_real_tdoa(self.ue_coor_dic[key], ap4)
        return ue_4dis


if __name__ == '__main__':
    data_path = "./data_huawei"
    s0514 = Scene(data_path)
    a=1


